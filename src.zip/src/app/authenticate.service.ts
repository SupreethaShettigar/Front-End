import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './model/User';
import { Injectable } from '@angular/core';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  loginStatus: boolean
  adminStatus: boolean
  currentUser: User

  constructor(public http: HttpClient) {
    this.loginStatus = false
    this.adminStatus = false
  }

  signIn(user: User) {
    return this.http.post('http://localhost:8888/grocery/signin', user, httpOptions)
  }

  signUp(user: User) {
    return this.http.post('http://localhost:8888/grocery/signup', user, httpOptions)
  }

  signOut() {
    return this.http.post('http://localhost:8888/grocery/signout', {}, httpOptions)
  }

}